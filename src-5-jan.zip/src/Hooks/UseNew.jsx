import { useContext } from "react";
import NewContext from "../Context/NewContext";
export const useNew = () =>useContext(NewContext);