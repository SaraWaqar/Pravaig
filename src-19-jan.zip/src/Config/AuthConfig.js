export default {
    meEndpoint: 'http://192.168.0.179:3700/',
    loginEndpoint: '/jwt/login',
    registerEndpoint: '/jwt/register',
    storageTokenKeyName: 'accessToken',
    refreshTokenKeyName: 'refreshToken',
  }
  