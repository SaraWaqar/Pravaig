import  {useContext} from 'react'
import { SliderContext } from '../Context/SliderContext'

export const UseSlider = () => useContext(SliderContext);

