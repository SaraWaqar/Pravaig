import React, { createContext, useState } from 'react'
const NewContext = createContext();

const newContext = ({children}) => {

    const values = {
        
    }
  return (
    <div>newContext</div>
  )
}

export default newContext